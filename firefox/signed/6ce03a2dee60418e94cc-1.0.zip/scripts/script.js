document.getElementById('onet-ad-flat-belkagorna').remove()
